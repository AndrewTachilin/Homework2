function Scope() {
}

module.exports = Scope;